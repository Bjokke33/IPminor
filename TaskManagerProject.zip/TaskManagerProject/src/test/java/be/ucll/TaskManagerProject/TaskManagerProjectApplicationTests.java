package be.ucll.TaskManagerProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagerProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
